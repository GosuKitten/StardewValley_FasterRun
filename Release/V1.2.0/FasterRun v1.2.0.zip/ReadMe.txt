FasterRun v1.2.0 by Kathryn Hazuka

Installation:
1. Extract folder to Stardew Valley's root directory.
2. Merge all folders.
3. Navigate to Mods/FasterRun/config.json and change the runSpeed to your desired speed (only integers) (default run speed is 5).
4. Play!

Updating:
1. Delete folder for previous version from <root directory>/Mods.
2. Extract new FasterRun folder to <root directory>/Mods.
3. Navigate to Mods/FasterRun/config.json and change the runSpeed to your desired speed (only integers) (default run speed is 5).
4. Play

The sorce code can be found here: https://github.com/KathrynHazuka/StardewValley_FasterRun
If you like the mod, please leave a comment and endorse the mod.

Thank you and enjoy!~
