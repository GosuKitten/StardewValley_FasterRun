FasterRun v1.0.0 by Kathryn Hazuka

Installation:
1. Extract folder to Stardew Valley's root directory.
2. Merge all folders and replace all files (if updating).
4. Navigate to Mods/FasterRun/FasterRun.ini and change the runSpeed to your desired speed (default run speed is 5).
5. Play!

The sorce code can be found here: https://github.com/KathrynHazuka/StardewValley_FasterRun
If you like the mod, please leave a comment and endorse the mod.

Thank you and enjoy!~
